#!/bin/sh
# Tests for the cuda-sieve P0/P1 patch, run against the PATCHED sources.
#   usage: sh run_tests.sh <dir with patched nfs_sieving.c nfs.c cmdOptions.c>
# Extracts the new code, compiles it against small stubs, and runs it with a mock
# "bench" script.  Needs gcc, python3, sh.  Does not need a GPU or the yafu build.
set -e
SRC=$(cd "${1:?usage: run_tests.sh <source dir>}" && pwd)
HERE=$(cd "$(dirname "$0")" && pwd)
W=$(mktemp -d); cp "$HERE"/stub.h "$HERE"/mock_bench.sh "$HERE"/test_range.c "$HERE"/test_nfs.c "$W"/; cd "$W"
python3 - "$SRC" <<'PY'
import sys, re
d = sys.argv[1]
rd = lambda n: open(d + '/' + n, 'rb').read().decode().replace('\r\n', '\n')
s = rd('nfs_sieving.c')
i = s.index('/*----------------------------------------------------------------------\n   External cuda-sieve backend')
j = s.index('#ifdef USE_THREADPOOL\nvoid nfs_sieve_start')
open('cuda_block.c', 'w').write(s[i:j])
n = rd('nfs.c')
i = n.index('int check_for_sievers(fact_obj_t *fobj, int revert_to_siqs)')
j = n.index('void nfs_set_sievername(fact_obj_t* fobj, nfs_job_t* job)')
open('extract_nfs.c', 'w').write(n[i:n.index('\n}\n', j) + 3])
c = rd('cmdOptions.c')
i = c.index('    else if (strcmp(opt, OptionArray[131]) == 0)')
j = c.index('    else\n    {\n        int i;\n\n        printf("invalid option %s\\n", opt);')
open('handler_body.c', 'w').write('    if (0) {}\n' + c[i:j])
PY
cat > handler_test.c <<'C'
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#define MAXARGLEN 256
typedef struct { char cuda_sieve[MAXARGLEN]; char cuda_dev[MAXARGLEN]; } options_t;
static char OptionArray[140][20];
static void handle(options_t* options, const char* opt, const char* arg)
{
#include "handler_body.c"
}
int main(void){
  options_t o; int fails=0; unsigned i;
  const char* good[]={"0","0,1","12,3,4"}; const char* bad[]={"","0,,1",",1","1,","a","0 1","-1","0;1"};
  strcpy(OptionArray[131],"cuda_sieve"); strcpy(OptionArray[132],"cuda_dev");
  for(i=0;i<3;i++){ strcpy(o.cuda_dev,"OLD"); handle(&o,"cuda_dev",good[i]); if(strcmp(o.cuda_dev,good[i])){printf("FAIL good %s\n",good[i]);fails++;} }
  for(i=0;i<8;i++){ strcpy(o.cuda_dev,"OLD"); handle(&o,"cuda_dev",bad[i]); if(strcmp(o.cuda_dev,"OLD")){printf("FAIL bad '%s'\n",bad[i]);fails++;} }
  handle(&o,"cuda_sieve","/path/to/bench"); if(strcmp(o.cuda_sieve,"/path/to/bench")){printf("FAIL sieve\n");fails++;}
  printf("options: %s\n", fails?"FAILED":"all passed"); return fails!=0; }
C
CC="gcc -std=gnu99 -D_DEFAULT_SOURCE -Wall -Wextra"
$CC -o test_range test_range.c
$CC -o test_nfs test_nfs.c 2>/dev/null
$CC -DWIN32 -o test_nfs_w test_nfs.c 2>/dev/null
$CC -o handler_test handler_test.c
chmod +x mock_bench.sh
echo "== cuda launcher (mock siever)"; ./test_range 2>&1 | grep -E 'FAIL|all passed|FAILED'
echo "== nfs.c: sievername + check_for_sievers"; ./test_nfs 2>&1 | grep -E 'FAIL|all passed|FAILED'
echo "== nfs.c, WIN32 branches"; ./test_nfs_w 2>&1 | grep -E 'FAIL|all passed|FAILED'
echo "== option handlers"; ./handler_test 2>&1 | grep -E 'FAIL|all passed|FAILED'
rm -rf "$W"

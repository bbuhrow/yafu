#!/bin/sh
# stands in for cuda-sieve's bench: records its arguments and behaves per $MOCK_MODE
echo "$@" > args.txt
out=""
while [ $# -gt 0 ]; do
  if [ "$1" = "--relations" ]; then out="$2"; fi
  shift
done
case "$MOCK_MODE" in
  ok)     printf 'r1\nr2\nr3\n' > "$out.part"; mv "$out.part" "$out"; exit 0;;
  stop)   printf 'r1\n' > "$out.part"; echo "next_q = 1500" > "$out.part.ckpt"; exit 0;;
  fail)   echo "poly_load: nfs.job:21: duplicate rlim field" >&2; exit 1;;
  exit3)  echo "norm too wide for BN_LIMBS" >&2; exit 3;;
  exit5)  printf 'r1\n' > "$out.part"; exit 5;;
  silent) exit 0;;
  kill)   kill -9 $$;;
esac

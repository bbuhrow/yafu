#include "stub.h"
#include <stdarg.h>
#define NFS_DEFAULT_PHASES 0
#define NFS_PHASE_SIEVE 1
static int siqs_calls = 0;
#define SIQS(f) (siqs_calls++)
#define mpz_set(a,b) ((void)0)
static void logprint_oc(const char* a, const char* m, const char* fmt, ...) { (void)a; (void)m; (void)fmt; }
#include "extract_nfs.c"

static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("  FAIL: %s (line %d)\n", #c, __LINE__); fails++; } } while (0)

int main(void)
{
    fact_obj_t f; nfs_job_t job; int r;
    memset(&f, 0, sizeof f); memset(&job, 0, sizeof job);
    strcpy(f.nfs_obj.ggnfs_dir, "./"); f.nfs_obj.siever = 14;

    nfs_set_sievername(&f, &job);
#if defined(WIN32)
    CHECK(strcmp(job.sievername, "./gnfs-lasieve4I14e.exe") == 0);
#else
    CHECK(strcmp(job.sievername, "./gnfs-lasieve4I14e") == 0);
#endif
    strcpy(f.nfs_obj.cuda_sieve, "/opt/cuda-sieve/bench/bench");
    nfs_set_sievername(&f, &job);
    CHECK(strcmp(job.sievername, "/opt/cuda-sieve/bench/bench") == 0);

    // cuda selected, binary present / missing
    r = check_for_sievers(&f, 1);           // /opt/... does not exist here
    CHECK(r == 1); CHECK(siqs_calls == 0);
    strcpy(f.nfs_obj.cuda_sieve, "./mock_bench.sh");
    r = check_for_sievers(&f, 1);
    CHECK(r == 0); CHECK(siqs_calls == 0);

    // lasieve path: no binaries -> siqs fallback, as before (and found is initialised now)
    f.nfs_obj.cuda_sieve[0] = 0; strcpy(f.nfs_obj.ggnfs_dir, "./nowhere/");
    r = check_for_sievers(&f, 1);
    CHECK(r == 1); CHECK(siqs_calls == 1);
    r = check_for_sievers(&f, 0);
    CHECK(r == 1); CHECK(siqs_calls == 1);
    // lasieve path: binary present
    system("mkdir -p fakedir && : > fakedir/gnfs-lasieve4I14e"
#if defined(WIN32)
           ".exe"
#endif
           );
    strcpy(f.nfs_obj.ggnfs_dir, "./fakedir/");
    r = check_for_sievers(&f, 1);
    CHECK(r == 0);
    system("rm -rf fakedir");

    printf("%s (%d failure(s))\n", fails ? "FAILED" : "all passed", fails);
    return fails != 0;
}

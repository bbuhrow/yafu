#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <inttypes.h>
#include <unistd.h>
#include <sys/wait.h>
#define GSTR_MAXSIZE 1024
#define MySleep(x) usleep((x)*1000)
typedef struct { char cuda_sieve[GSTR_MAXSIZE]; char cuda_dev[GSTR_MAXSIZE]; char job_infile[GSTR_MAXSIZE];
                 char ggnfs_dir[GSTR_MAXSIZE]; uint32_t siever; uint32_t nfs_phases; } nfs_obj_t;
typedef struct { int dummy; } qs_obj_t_stub;
typedef struct { int gmp_n; } qs_stub;
typedef struct { int VFLAG; int THREADS; char flogname[64]; nfs_obj_t nfs_obj; qs_stub qs_obj; } fact_obj_t;
enum special_q_e { NEITHER_SPQ, ALGEBRAIC_SPQ, RATIONAL_SPQ };
typedef struct { enum special_q_e side; } mpz_polys_t;
typedef struct { mpz_polys_t* poly; char sievername[1024]; uint32_t startq, qrange, current_rels; } nfs_job_t;
typedef struct { char outfilename[80]; nfs_job_t job; uint32_t siever; int tindex; } nfs_threaddata_t;
int NFS_ABORT = 0;
#define NFS_USE_CUDA(fobj) ((fobj)->nfs_obj.cuda_sieve[0] != '\0')

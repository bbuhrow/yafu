#include "stub.h"
#include "cuda_block.c"

static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("  FAIL: %s (line %d)\n", #c, __LINE__); fails++; } } while (0)

static int exists(const char* n) { return nfs_cuda_file_exists(n); }

static void setup(fact_obj_t* f, nfs_threaddata_t* t, mpz_polys_t* p, const char* mode)
{
    memset(f, 0, sizeof(*f)); memset(t, 0, sizeof(*t));
    strcpy(f->nfs_obj.cuda_sieve, "./mock_bench.sh");
    strcpy(f->nfs_obj.job_infile, "nfs.job");
    f->VFLAG = 1;
    p->side = ALGEBRAIC_SPQ;
    t->job.poly = p; strcpy(t->job.sievername, "./mock_bench.sh");
    t->job.startq = 1000; t->job.qrange = 1000; t->siever = 14; t->tindex = 0;
    strcpy(t->outfilename, "rels0_0.dat");
    setenv("MOCK_MODE", mode, 1);
    NFS_ABORT = 0;
    remove("args.txt");
}

int main(void)
{
    fact_obj_t f; nfs_threaddata_t t; mpz_polys_t p; char line[512];
    FILE* a;

    printf("[ok]\n");
    setup(&f, &t, &p, "ok"); t.job.current_rels = 999;
    nfs_cuda_sieve_range(&f, &t);
    CHECK(t.job.current_rels == 3); CHECK(NFS_ABORT == 0);
    CHECK(exists("rels0_0.dat")); CHECK(!exists("rels0_0.dat.log")); CHECK(!exists("rels0_0.dat.part"));
    a = fopen("args.txt", "r"); CHECK(a != NULL);
    if (a) { fgets(line, sizeof line, a); fclose(a); printf("  args: %s", line);
        CHECK(strstr(line, "--pipeline --cofactor --poly nfs.job --logI 14 --qrange 1000:1999 --sq-side 1 --relations rels0_0.dat --restart --device 0") != NULL); }
    remove("rels0_0.dat");

    printf("[rational side, dev list]\n");
    setup(&f, &t, &p, "ok"); p.side = RATIONAL_SPQ; strcpy(f.nfs_obj.cuda_dev, "2,5,7"); t.tindex = 4; t.siever = 15;
    nfs_cuda_sieve_range(&f, &t);
    a = fopen("args.txt", "r"); fgets(line, sizeof line, a); fclose(a);
    CHECK(strstr(line, "--sq-side 0") && strstr(line, "--device 5") && strstr(line, "--logI 15"));
    remove("rels0_0.dat");

    printf("[device round robin]\n");
    strcpy(f.nfs_obj.cuda_dev, "2,5,7");
    CHECK(nfs_cuda_device(&f, 0) == 2); CHECK(nfs_cuda_device(&f, 1) == 5);
    CHECK(nfs_cuda_device(&f, 2) == 7); CHECK(nfs_cuda_device(&f, 3) == 2); CHECK(nfs_cuda_ndev(&f) == 3);
    strcpy(f.nfs_obj.cuda_dev, "12");
    CHECK(nfs_cuda_device(&f, 3) == 12); CHECK(nfs_cuda_ndev(&f) == 1);
    f.nfs_obj.cuda_dev[0] = 0;
    CHECK(nfs_cuda_device(&f, 3) == 0); CHECK(nfs_cuda_ndev(&f) == 1);

    printf("[clean stop: exit 0, only .part]\n");
    setup(&f, &t, &p, "stop");
    nfs_cuda_sieve_range(&f, &t);
    CHECK(NFS_ABORT == 1); CHECK(t.job.current_rels == 0); CHECK(!exists("rels0_0.dat"));
    CHECK(!exists("rels0_0.dat.part")); CHECK(!exists("rels0_0.dat.part.ckpt"));

    printf("[failure exit 1 with message]\n");
    setup(&f, &t, &p, "fail");
    nfs_cuda_sieve_range(&f, &t);
    CHECK(NFS_ABORT == 1); CHECK(t.job.current_rels == 0); CHECK(exists("rels0_0.dat.log"));
    remove("rels0_0.dat.log");

    printf("[exit 3]\n");
    setup(&f, &t, &p, "exit3"); nfs_cuda_sieve_range(&f, &t); CHECK(NFS_ABORT == 1); remove("rels0_0.dat.log");
    printf("[exit 5 leaves .part]\n");
    setup(&f, &t, &p, "exit5"); nfs_cuda_sieve_range(&f, &t); CHECK(NFS_ABORT == 1); CHECK(!exists("rels0_0.dat.part")); remove("rels0_0.dat.log");

    printf("[exit 0 but nothing produced]\n");
    setup(&f, &t, &p, "silent"); nfs_cuda_sieve_range(&f, &t); CHECK(NFS_ABORT == 1); remove("rels0_0.dat.log");

    printf("[killed by signal]\n");
    setup(&f, &t, &p, "kill"); nfs_cuda_sieve_range(&f, &t); CHECK(NFS_ABORT == 1); remove("rels0_0.dat.log");

    printf("[missing binary]\n");
    setup(&f, &t, &p, "ok"); strcpy(t.job.sievername, "./does_not_exist");
    nfs_cuda_sieve_range(&f, &t); CHECK(NFS_ABORT == 1); CHECK(t.job.current_rels == 0); remove("rels0_0.dat.log");

    printf("[qrange 0: nothing launched]\n");
    setup(&f, &t, &p, "ok"); t.job.qrange = 0; nfs_cuda_sieve_range(&f, &t);
    CHECK(NFS_ABORT == 0); CHECK(!exists("args.txt"));

    printf("[logI out of range]\n");
    setup(&f, &t, &p, "ok"); t.siever = 21; nfs_cuda_sieve_range(&f, &t); CHECK(NFS_ABORT == 1); CHECK(!exists("args.txt"));
    setup(&f, &t, &p, "ok"); t.siever = 1;  nfs_cuda_sieve_range(&f, &t); CHECK(NFS_ABORT == 1); CHECK(!exists("args.txt"));

    printf("[end of q space in 64 bits]\n");
    setup(&f, &t, &p, "ok"); t.job.startq = 4294967000u; t.job.qrange = 1000; nfs_cuda_sieve_range(&f, &t);
    a = fopen("args.txt", "r"); fgets(line, sizeof line, a); fclose(a);
    CHECK(strstr(line, "--qrange 4294967000:4294967999") != NULL);
    remove("rels0_0.dat");

    printf("[stale files from an earlier run are cleared]\n");
    setup(&f, &t, &p, "ok");
    { FILE* s = fopen("rels0_0.dat.part", "w"); fputs("stale\n", s); fclose(s); s = fopen("rels0_0.dat.lock", "w"); fputs("1\n", s); fclose(s); }
    nfs_cuda_sieve_range(&f, &t); CHECK(t.job.current_rels == 3); CHECK(!exists("rels0_0.dat.lock"));
    remove("rels0_0.dat");

    printf("[command line too long]\n");
    setup(&f, &t, &p, "ok"); memset(f.nfs_obj.job_infile, 'j', 1000); f.nfs_obj.job_infile[1000] = 0; memset(t.job.sievername, 's', 100); t.job.sievername[100] = 0;
    nfs_cuda_sieve_range(&f, &t); CHECK(NFS_ABORT == 1);

    printf("\n%s (%d failure(s))\n", fails ? "FAILED" : "all passed", fails);
    return fails != 0;
}
